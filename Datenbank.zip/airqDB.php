﻿<?php
	
	function createAirqTableIfNotExists() {
    global $db_servername;
    global $db_port;
    global $db_username;
    global $db_password;
    global $db_name;
 	global $table;
 	global $sql;

		$sql = "CREATE TABLE IF NOT EXISTS `" . $table . "` (
			  `ID` BIGINT NOT NULL AUTO_INCREMENT
			,  `measuredAt` DATETIME COMMENT 'Zeitstempel zu den Messwerten.' 
			, `DeviceID` VARCHAR(32) COMMENT 'Identifiziert den Air-Q eindeutig.' 
			, `Device` VARCHAR(32) COMMENT 'Der vom Air-Q an service.php übergebene Device-Name.' 
			, `measuretime` INT DEFAULT NULL COMMENT 'Zeit in ms, die für den gesamten letzten Messdurchlauf benötigt wurde.' 
			, `uptime` INT DEFAULT NULL COMMENT 'Laufzeit des air-Q in ms seit dem letzten Neustart.' 
			, `health` FLOAT DEFAULT NULL COMMENT 'Berechneter Gesundheitsindex. Bereich 0 bis 1000: normale Bewertung. -200 bei Gasalarm. -800 bei Feueralarm.'
			, `performance` FLOAT DEFAULT NULL COMMENT 'Berechneter Leistungsindex.'
			, `temperature` FLOAT DEFAULT NULL COMMENT 'Temperatur in °C.'
			, `temperature_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `dewpt` FLOAT DEFAULT NULL COMMENT 'Taupunkt in °C.'
			, `dewpt_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `humidity` FLOAT DEFAULT NULL COMMENT 'Relative Luftfeuchtigkeit in %.'
			, `humidity_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `humidity_abs` FLOAT DEFAULT NULL COMMENT 'Absolute Luftfeuchtigkeit in g/m3.'
			, `humidity_abs_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `dHdt` FLOAT DEFAULT NULL COMMENT 'Änderungsrate der absoluten Luftfeuchtigkeit in g/m3/s.'
			, `oxygen` FLOAT DEFAULT NULL COMMENT 'Sauerstoff-Konzentration in Volumen-Prozent.'
			, `oxygen_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `o3` FLOAT DEFAULT NULL COMMENT 'O3-Konzentration in µg/m3.'
			, `o3_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `co` FLOAT DEFAULT NULL COMMENT 'CO-Konzentration in ppm.'
			, `co_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `co2` FLOAT DEFAULT NULL COMMENT 'CO2-Konzentration in ppm.'
			, `co2_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `dCO2dt` FLOAT DEFAULT NULL COMMENT 'CO2-Änderungsrate in ppm/s.'
			, `no2` FLOAT DEFAULT NULL COMMENT 'NO2-Konzentration in µg/m3.'
			, `no2_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `so2` FLOAT DEFAULT NULL COMMENT 'SO2-Konzentration in µg/m3.'
			, `so2_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `tvoc` FLOAT DEFAULT NULL COMMENT 'VOC-Konzentration in ppb.'
			, `tvoc_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `pm1` FLOAT DEFAULT NULL COMMENT 'Feinstaubkonzentration für die Partikel 1.0 µm in µg/m3.'
			, `pm1_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `pm2_5` FLOAT DEFAULT NULL COMMENT 'Feinstaubkonzentration für die Partikel 2.5 µm in µg/m3.'
			, `pm2_5_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `pm10` FLOAT DEFAULT NULL COMMENT ' Feinstaubkonzentration für die Partikel 10 µm in µg/m3.'
			, `pm10_e` FLOAT DEFAULT NULL COMMENT ' Abweichung (errorrate) in sensors unit.'
			, `cnt0_3` FLOAT DEFAULT NULL COMMENT 'Die Gesamtzahl der Feinstaub-Partikel größer als 0,3 µm.'
			, `cnt0_3_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `cnt0_5` FLOAT DEFAULT NULL COMMENT 'Die Gesamtzahl der Feinstaub-Partikel größer als 0,5 µm.'
			, `cnt0_5_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `cnt1` FLOAT DEFAULT NULL COMMENT 'Die Gesamtzahl der Feinstaub-Partikel größer als 1 µm.'
			, `cnt1_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `cnt2_5` FLOAT DEFAULT NULL COMMENT 'Die Gesamtzahl der Feinstaub-Partikel größer als 2,5 µm.'
			, `cnt2_5_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `cnt5` FLOAT DEFAULT NULL COMMENT 'Die Gesamtzahl der Feinstaub-Partikel größer als 5 µm.'
			, `cnt5_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `cnt10` FLOAT DEFAULT NULL COMMENT 'Die Gesamtzahl der Feinstaub-Partikel größer als 10 µm.'
			, `cnt10_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `TypPS` FLOAT DEFAULT NULL COMMENT ' Die durchschnittliche Partikelgröße in µm.'
			, `sound` FLOAT DEFAULT NULL COMMENT 'Lärm in dB(A).'
			, `sound_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `sound_max` FLOAT DEFAULT NULL COMMENT 'Maimaler Lärm in dB(A).'
			, `sound_max_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `pressure` FLOAT DEFAULT NULL COMMENT 'Luftdruck in hPa.'
			, `pressure_e` FLOAT DEFAULT NULL COMMENT 'Abweichung (errorrate) in sensors unit.'
			, `Status`  VARCHAR(10000) COMMENT 'Aktueller Messungsstatus.'
			,  PRIMARY KEY (`ID`) USING BTREE
			,  KEY `Dev_mAt` (`Device`,`measuredAt`)
			)
			ENGINE = InnoDB;
		";

		$mysqli = mysqli_connect($db_servername, $db_username, $db_password, $db_name, $db_port);
		$stmt = mysqli_prepare($mysqli, $sql);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_close($stmt);
	}
	
	function insertAirqValues($device, $data) {
    global $db_servername;
    global $db_port;
    global $db_username;
    global $db_password;
    global $db_name;
 	global $table;
 	global $sql;

		$json = json_decode($data, true);
		if (array_key_exists('Status', $json)) {
			if (is_array($json["Status"])) {
				$status = json_encode($json["Status"]);
			} else {
				$status = $json["Status"];
			}
		} else {
			$status = "";
		}

		createAirqTableIfNotExists();

		$sql = "INSERT INTO `" . $table ."`
		(
			  `measuredAt`
			, `DeviceID`
			, `Device`
			, `measuretime`
			, `uptime` 
			, `health`
			, `performance`
			, `temperature`
			, `temperature_e`
			, `dewpt`
			, `dewpt_e`
			, `humidity`
			, `humidity_e`
			, `humidity_abs`
			, `humidity_abs_e`
			, `dHdt`
			, `oxygen`
			, `oxygen_e`
			, `o3`
			, `o3_e`
			, `co`
			, `co_e`
			, `co2`
			, `co2_e`
			, `dCO2dt`
			, `no2`
			, `no2_e`
			, `so2`
			, `so2_e`
			, `tvoc`
			, `tvoc_e`
			, `pm1`
			, `pm1_e`
			, `pm2_5`
			, `pm2_5_e`
			, `pm10`
			, `pm10_e`
			, `cnt0_3`
			, `cnt0_3_e`
			, `cnt0_5`
			, `cnt0_5_e`
			, `cnt1`
			, `cnt1_e`
			, `cnt2_5`
			, `cnt2_5_e`
			, `cnt5`
			, `cnt5_e`
			, `cnt10`
			, `cnt10_e`
			, `TypPS`
			, `sound`
			, `sound_e`
			, `sound_max`
			, `sound_max_e`
			, `pressure`
			, `pressure_e`
			, `Status`
		) 
		VALUES (
			  FROM_UNIXTIME(" . $json["timestamp"]/1000 . ")
			, '" . $json["DeviceID"] . "'
			, '" . $device . "'
			, " . ((array_key_exists('measuretime', $json)) ? ($json["measuretime"]) : ("NULL")) . "
			, " . ((array_key_exists('uptime', $json)) ? ($json["uptime"]) : ("NULL")) . "
			, " . ((array_key_exists('health', $json)) ? ($json["health"]) : ("NULL")) . "
			, " . ((array_key_exists('performance', $json)) ? ($json["performance"]) : ("NULL")) . "
			, " . ((array_key_exists('temperature', $json)) ? ($json["temperature"][0]) : ("NULL")) . "
			, " . ((array_key_exists('temperature', $json)) ? ($json["temperature"][1]) : ("NULL")) . "
			, " . ((array_key_exists('dewpt', $json)) ? ($json["dewpt"][0]) : ("NULL")) . "
			, " . ((array_key_exists('dewpt', $json)) ? ($json["dewpt"][1]) : ("NULL")) . "
			, " . ((array_key_exists('humidity', $json)) ? ($json["humidity"][0]) : ("NULL")) . "
			, " . ((array_key_exists('humidity', $json)) ? ($json["humidity"][1]) : ("NULL")) . "
			, " . ((array_key_exists('humidity_abs', $json)) ? ($json["humidity_abs"][0]) : ("NULL")) . "
			, " . ((array_key_exists('humidity_abs', $json)) ? ($json["humidity_abs"][1]) : ("NULL")) . "
			, " . ((array_key_exists('dHdt', $json)) ? ($json["dHdt"]) : ("NULL")) . "
			, " . ((array_key_exists('oxygen', $json)) ? ($json["oxygen"][0]) : ("NULL")) . "
			, " . ((array_key_exists('oxygen', $json)) ? ($json["oxygen"][1]) : ("NULL")) . "
			, " . ((array_key_exists('o3', $json)) ? ($json["o3"][0]) : ("NULL")) . "
			, " . ((array_key_exists('o3', $json)) ? ($json["o3"][1]) : ("NULL")) . "
			, " . ((array_key_exists('co', $json)) ? ($json["co"][0]) : ("NULL")) . "
			, " . ((array_key_exists('co', $json)) ? ($json["co"][1]) : ("NULL")) . "
			, " . ((array_key_exists('co2', $json)) ? ($json["co2"][0]) : ("NULL")) . "
			, " . ((array_key_exists('co2', $json)) ? ($json["co2"][1]) : ("NULL")) . "
			, " . ((array_key_exists('dCO2dt', $json)) ? ($json["dCO2dt"]) : ("NULL")) . "
			, " . ((array_key_exists('no2', $json)) ? ($json["no2"][0]) : ("NULL")) . "
			, " . ((array_key_exists('no2', $json)) ? ($json["no2"][1]) : ("NULL")) . "
			, " . ((array_key_exists('so2', $json)) ? ($json["so2"][0]) : ("NULL")) . "
			, " . ((array_key_exists('so2', $json)) ? ($json["so2"][1]) : ("NULL")) . "
			, " . ((array_key_exists('tvoc', $json)) ? ($json["tvoc"][0]) : ("NULL")) . "
			, " . ((array_key_exists('tvoc', $json)) ? ($json["tvoc"][1]) : ("NULL")) . "
			, " . ((array_key_exists('pm1', $json)) ? ($json["pm1"][0]) : ("NULL")) . "
			, " . ((array_key_exists('pm1', $json)) ? ($json["pm1"][1]) : ("NULL")) . "
			, " . ((array_key_exists('pm2_5', $json)) ? ($json["pm2_5"][0]) : ("NULL")) . "
			, " . ((array_key_exists('pm2_5', $json)) ? ($json["pm2_5"][1]) : ("NULL")) . "
			, " . ((array_key_exists('pm10', $json)) ? ($json["pm10"][0]) : ("NULL")) . "
			, " . ((array_key_exists('pm10', $json)) ? ($json["pm10"][1]) : ("NULL")) . "
			, " . ((array_key_exists('cnt0_3', $json)) ? ($json["cnt0_3"][0]) : ("NULL")) . "
			, " . ((array_key_exists('cnt0_3', $json)) ? ($json["cnt0_3"][1]) : ("NULL")) . "
			, " . ((array_key_exists('cnt0_5', $json)) ? ($json["cnt0_5"][0]) : ("NULL")) . "
			, " . ((array_key_exists('cnt0_5', $json)) ? ($json["cnt0_5"][1]) : ("NULL")) . "
			, " . ((array_key_exists('cnt1', $json)) ? ($json["cnt1"][0]) : ("NULL")) . "
			, " . ((array_key_exists('cnt1', $json)) ? ($json["cnt1"][1]) : ("NULL")) . "
			, " . ((array_key_exists('cnt2_5', $json)) ? ($json["cnt2_5"][0]) : ("NULL")) . "
			, " . ((array_key_exists('cnt2_5', $json)) ? ($json["cnt2_5"][1]) : ("NULL")) . "
			, " . ((array_key_exists('cnt5', $json)) ? ($json["cnt5"][0]) : ("NULL")) . "
			, " . ((array_key_exists('cnt5', $json)) ? ($json["cnt5"][1]) : ("NULL")) . "
			, " . ((array_key_exists('cnt10', $json)) ? ($json["cnt10"][0]) : ("NULL")) . "
			, " . ((array_key_exists('cnt10', $json)) ? ($json["cnt10"][1]) : ("NULL")) . "
			, " . ((array_key_exists('TypPS', $json)) ? ($json["TypPS"]) : ("NULL")) . "
			, " . ((array_key_exists('sound', $json)) ? ($json["sound"][0]) : ("NULL")) . "
			, " . ((array_key_exists('sound', $json)) ? ($json["sound"][1]) : ("NULL")) . "
			, " . ((array_key_exists('sound_max', $json)) ? ($json["sound_max"][0]) : ("NULL")) . "
			, " . ((array_key_exists('sound_max', $json)) ? ($json["sound_max"][1]) : ("NULL")) . "
			, " . ((array_key_exists('pressure', $json)) ? ($json["pressure"][0]) : ("NULL")) . "
			, " . ((array_key_exists('pressure', $json)) ? ($json["pressure"][1]) : ("NULL")) . "
			, '" . $status . "'
		);";
		
		$mysqli = mysqli_connect($db_servername, $db_username, $db_password, $db_name, $db_port);
		$stmt = mysqli_prepare($mysqli, $sql);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_close($stmt);
	}

?>