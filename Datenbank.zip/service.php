﻿<?php

	include('config.php');
	include('airqDB.php');
	include('airqExtMQTT.php');
	if ($server != "") {
		include('mqttBasics.php');
	}

	$sql=""; // global variable to log SQL-Statements in case of error


	set_error_handler(function($errno, $errstr, $errfile, $errline ){
		throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
	});

	$_GET_lower = array_change_key_case($_GET, CASE_LOWER);
	$_POST_lower = array_change_key_case($_POST, CASE_LOWER);
	$device = '';
	if (array_key_exists('device', $_GET_lower)) {$device = $_GET_lower['device'];}
	if (array_key_exists('device', $_POST_lower)) {$device = $_POST_lower['device'];}
	if ($device == "") {$device = "unknown";}
	
	$table = str_replace('#device#', $device, $table);
	$topic = str_replace('#device#', $device, $topic);
	$topicExt = str_replace('#device#', $device, $topicExt);

	$log_txt = '--------------------------------------------' . "\r\n";
	$log_txt = $log_txt . date('Y-m-d H:i:s') . ": ";
	$log_txt = $log_txt . 'Server(REMOTE_ADDR) = ' . $_SERVER['REMOTE_ADDR'] . "\r\n";
	$log_txt = $log_txt . 'Device = ' . $device . "\r\n";
	myLog($log_txt);
	$log_txt = "Content\r\n";
	$data = file_get_contents('php://input');
	$log_txt = $log_txt . $data . "\r\n";

	try {
		if ($server != "") {
			if ($topic != "") {
				publish_message($topic, $data);
				$log_txt = $log_txt . "... values published via MQTT with topic " . $topic . "\r\n" ;
			}
			if ($topicExt != "") {
				publish_message($topicExt, extendTopics ($data));
				$log_txt = $log_txt . "... extended values published via MQTT with topic " . $topicExt . "\r\n" ;
			}
		}
		if ($db_servername != "") {
			insertAirqValues($device, $data);
			$log_txt = $log_txt . "... values inserted into table " . $table . "\r\n" ;
		}
	}
	catch(Exception $e) {
		$log_txt = $log_txt . "\r\n" . 'Error: ' . $e->getMessage() . "\r\n" ;
		$log_txt = $log_txt . "\r\n" . $sql . "\r\n" ;
	}

	myLog($log_txt);
	myLog('--------------------------------------------' . "\r\n");

	header('Access-Control-Allow-Origin: *'); 
	header('Content-Type: application/json');
	echo '{"result":"http-post received"}';


	function myLog($log_txt) {
		global $logfile;
		global $debug;
		if ($debug != 0) {
			if (!file_exists($logfile)) {   
				file_put_contents($logfile, "\xEF\xBB\xBF", FILE_APPEND); // Create log file as BOM UTF-8
			}
			file_put_contents($logfile, $log_txt, FILE_APPEND);
		}
	}

?> 
