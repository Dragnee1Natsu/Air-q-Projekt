﻿<?php

// uses https://github.com/mgdm/Mosquitto-PHP 
// see http://mosquitto-php.readthedocs.io/ for api documents
// see http://www.notespoint.com/php-pubsub-mosquitto-mqtt/ for other examples
// requirement for installation see  http://www.notespoint.com/mosquitto-php-library-install/

include("config.php");

	$statusmsg = "";	
	$rcv_message = "";
	
function get_message($topic) {
	
	global $server; 	
	global $port;
	global $username;
	global $password;
	global $client_id;
	global $keepalive;
	global $statusmsg;
	global $rcv_message;
	
	read_topic($topic, $server, $port, $keepalive, 5);	
	
	if(!empty($rcv_message) ) {
		return $rcv_message;
	} else {
		return $statusmsg."TIMEDOUT"; 	
	}		
}

function publish_message($topic, $msg) {
	
	global $server; 	
	global $port;
	global $username;
	global $password;
	global $client_id;
	global $keepalive;
	
	$client = new Mosquitto\Client($client_id);
	$client->onConnect('connect');
	$client->onDisconnect('disconnect');
	$client->onPublish('publish');
	$client->connect($server, $port, $keepalive);
	
	try {
		$client->loop();
//		$mid = $client->publish($topic, $msg);
		$mid = $client->publish($topic, $msg, 1, true);  //QoS=1, Retain=true
		$client->loop();
		}catch(Mosquitto\Exception $e){
				echo 'Exception publish_message: ' . $e . '';          
				return;
			}
	$client->disconnect();
	unset($client);					    
}

function read_topic($topic, $server, $port, $keepalive, $timeout) {
	$client = new Mosquitto\Client();
	$client->onConnect('connect');
	$client->onDisconnect('disconnect');
	$client->onSubscribe('subscribe');
	$client->onMessage('message');
	$client->connect($server, $port, $keepalive);
	$client->subscribe($topic, 1);
	
	$date1 = time();
	$GLOBALS['rcv_message'] = '';
	while (true) {
			$client->loop();
			sleep(1);
			$date2 = time();
			if (($date2 - $date1) > $timeout) break;
			if(!empty($GLOBALS['rcv_message'])) {
//				echo $GLOBALS['rcv_message'] ;
				break;
			}
	}
	 
	$client->disconnect();
	unset($client);						
} 

/*****************************************************************
 * Call back functions for MQTT library
 * ***************************************************************/					
function connect($r) {
//		if($r == 0) echo "{$r}-CONX-OK|";
		if($r == 1) echo "{$r}-Connection refused (unacceptable protocol version)|";
		if($r == 2) echo "{$r}-Connection refused (identifier rejected)|";
		if($r == 3) echo "{$r}-Connection refused (broker unavailable )|";        
}
 
function publish() {
        echo "Mesage published:";
}
 
function disconnect() {
//        echo "Disconnected|";
}

function subscribe() {
	    //**Store the status to a global variable - debug purposes 
		$GLOBALS['statusmsg'] = $GLOBALS['statusmsg'] . "SUB-OK|";
}

function message($message) {
	    //**Store the status to a global variable - debug purposes
		$GLOBALS['statusmsg']  = "RX-OK|";
		
		//**Store the received message to a global variable
		$GLOBALS['rcv_message'] =  $message->payload;
}

?>
