﻿<?php

// for database connection
    $db_servername = "localhost";		// set your Database Server, empty string == no database
    $db_port = 3307;				// port to Database Server
    $db_username = "airq";				// set your DB user
    $db_password = "airq-passwort";		// set your DB passowrd
    $db_name = "airq";					// set your database

//    date_default_timezone_set('Europe/Berlin');
	
	// choose only one of the following alternatives
// 	$table = 'data'; 					// only one table for the whole lifecycle, can grow to a very big file
// 	$table = 'data' . date('Y'); 		// for yearly tables
// 	$table = 'data' . date('Y-m');		// for monthly tables
// 	$table = 'data' . date('Y-W');		// for weekly tables
// 	$table = 'data' . date('Y-m-d');	// for daily tables

// in most cases it is better to define one table for each device!!

 	$table = '#device#';					// one table for each device for the whole lifecycle, can grow to a very big file
// 	$table = '#device#' . date('Y'); 		// for yearly tables for each device
// 	$table = '#device#' . date('Y-m');		// for monthly tables for each device
// 	$table = '#device#' . date('Y-W');		// for weekly tables for each device
// 	$table = '#device#' . date('Y-m-d');	// for daily tables for each device

// but also you can use partitioning later
// but before 1. Mio. entries it is not necessary or helpfully
// and 1. Mio. entries you have after about 3.8 years (SecondsMeasurementDelay=120)

// for MQTT: see mqttBasics.php
	$server 		= "<IP-Adresse des MQTT-Broker>";					// set your MQTT-Server, empty string == no mqtt
	$port 			= 1883;                 			// change if necessary
	$username 		= "";                   			// set your username
	$password 		= "";                   			// set your password
	$client_id 		= uniqid();			    			// make sure this is unique for connecting to sever - you could use uniqid()
	$keepalive 		= 5;
//	$topic			= "airQ/01/sensordata"; 			// change if necessary
	$topic			= "#device#/sensor";				// change if necessary
//	$topicExt		= "airQ/01/sensordata/ext"; 		// change if necessary
	$topicExt		= "#device#/sensor/ext"; 			// change if necessary

// debug options
	$debug				= 1;									// 0 == debug off == no log file, else == log file $logfile
	$logfile 			= 'log' . date('Y-m-d') . '.txt';		// a new file for every day "log<yyyy-mm-dd>.txt", change if necessary
?>
