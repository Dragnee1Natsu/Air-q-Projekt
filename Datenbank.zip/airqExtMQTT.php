﻿<?php
	
	function extendTopics ($data) {

		$json = json_decode($data, true);
		if (array_key_exists('Status', $json)) {
			if (is_array($json["Status"])) {
				$status = json_encode($json["Status"]);
			} else {
				$status = $json["Status"];
			}
		} else {
			$status = "";
		}

		$jsonExt["measured"] = $json["timestamp"]/1000;
		$jsonExt["measuredAt"] = date("d.m.Y H:i:s",$json["timestamp"]/1000);
		$jsonExt["DeviceID"] = $json["DeviceID"];
		$jsonExt["measuretime"] = ((array_key_exists('measuretime', $json)) ? ($json["measuretime"]) : ( -1));
		$jsonExt["uptime" ] = ((array_key_exists('uptime', $json)) ? ($json["uptime"]) : ( -1));
		$jsonExt["health"] = ((array_key_exists('health', $json)) ? ($json["health"]) : ( -1));
		$jsonExt["performance"] = ((array_key_exists('performance', $json)) ? ($json["performance"]) : ( -1));
		$jsonExt["temperature"] = ((array_key_exists('temperature', $json)) ? ($json["temperature"][0]) : ( -1));
		$jsonExt["temperature_e"] = ((array_key_exists('temperature', $json)) ? ($json["temperature"][1]) : ( -1));
		$jsonExt["dewpt"] = ((array_key_exists('dewpt', $json)) ? ($json["dewpt"][0]) : ( -1));
		$jsonExt["dewpt_e"] = ((array_key_exists('dewpt', $json)) ? ($json["dewpt"][1]) : ( -1));
		$jsonExt["humidity"] = ((array_key_exists('humidity', $json)) ? ($json["humidity"][0]) : ( -1));
		$jsonExt["humidity_e"] = ((array_key_exists('humidity', $json)) ? ($json["humidity"][1]) : ( -1));
		$jsonExt["humidity_abs"] = ((array_key_exists('humidity_abs', $json)) ? ($json["humidity_abs"][0]) : ( -1));
		$jsonExt["humidity_abs_e"] = ((array_key_exists('humidity_abs', $json)) ? ($json["humidity_abs"][1]) : ( -1));
		$jsonExt["dHdt"] = ((array_key_exists('dHdt', $json)) ? ($json["dHdt"]) : ( -1));
		$jsonExt["oxygen"] = ((array_key_exists('oxygen', $json)) ? ($json["oxygen"][0]) : ( -1));
		$jsonExt["oxygen_e"] = ((array_key_exists('oxygen', $json)) ? ($json["oxygen"][1]) : ( -1));
		$jsonExt["o3"] = ((array_key_exists('o3', $json)) ? ($json["o3"][0]) : ( -1));
		$jsonExt["o3_e"] = ((array_key_exists('o3', $json)) ? ($json["o3"][1]) : ( -1));
		$jsonExt["co"] = ((array_key_exists('co', $json)) ? ($json["co"][0]) : ( -1));
		$jsonExt["co_e"] = ((array_key_exists('co', $json)) ? ($json["co"][1]) : ( -1));
		$jsonExt["co2"] = ((array_key_exists('co2', $json)) ? ($json["co2"][0]) : ( -1));
		$jsonExt["co2_e"] = ((array_key_exists('co2', $json)) ? ($json["co2"][1]) : ( -1));
		$jsonExt["dCO2dt"] = ((array_key_exists('dCO2dt', $json)) ? ($json["dCO2dt"]) : ( -1));
		$jsonExt["no2"] = ((array_key_exists('no2', $json)) ? ($json["no2"][0]) : ( -1));
		$jsonExt["no2_e"] = ((array_key_exists('no2', $json)) ? ($json["no2"][1]) : ( -1));
		$jsonExt["so2"] = ((array_key_exists('so2', $json)) ? ($json["so2"][0]) : ( -1));
		$jsonExt["so2_e"] = ((array_key_exists('so2', $json)) ? ($json["so2"][1]) : ( -1));
		$jsonExt["tvoc"] = ((array_key_exists('tvoc', $json)) ? ($json["tvoc"][0]) : ( -1));
		$jsonExt["tvoc_e"] = ((array_key_exists('tvoc', $json)) ? ($json["tvoc"][1]) : ( -1));
		$jsonExt["pm1"] = ((array_key_exists('pm1', $json)) ? ($json["pm1"][0]) : ( -1));
		$jsonExt["pm1_e"] = ((array_key_exists('pm1', $json)) ? ($json["pm1"][1]) : ( -1));
		$jsonExt["pm2_5"] = ((array_key_exists('pm2_5', $json)) ? ($json["pm2_5"][0]) : ( -1));
		$jsonExt["pm2_5_e"] = ((array_key_exists('pm2_5', $json)) ? ($json["pm2_5"][1]) : ( -1));
		$jsonExt["pm10"] = ((array_key_exists('pm10', $json)) ? ($json["pm10"][0]) : ( -1));
		$jsonExt["pm10_e"] = ((array_key_exists('pm10', $json)) ? ($json["pm10"][1]) : ( -1));
		$jsonExt["cnt0_3"] = ((array_key_exists('cnt0_3', $json)) ? ($json["cnt0_3"][0]) : ( -1));
		$jsonExt["cnt0_3_e"] = ((array_key_exists('cnt0_3', $json)) ? ($json["cnt0_3"][1]) : ( -1));
		$jsonExt["cnt0_5"] = ((array_key_exists('cnt0_5', $json)) ? ($json["cnt0_5"][0]) : ( -1));
		$jsonExt["cnt0_5_e"] = ((array_key_exists('cnt0_5', $json)) ? ($json["cnt0_5"][1]) : ( -1));
		$jsonExt["cnt1"] = ((array_key_exists('cnt1', $json)) ? ($json["cnt1"][0]) : ( -1));
		$jsonExt["cnt1_e"] = ((array_key_exists('cnt1', $json)) ? ($json["cnt1"][1]) : ( -1));
		$jsonExt["cnt2_5"] = ((array_key_exists('cnt2_5', $json)) ? ($json["cnt2_5"][0]) : ( -1));
		$jsonExt["cnt2_5_e"] = ((array_key_exists('cnt2_5', $json)) ? ($json["cnt2_5"][1]) : ( -1));
		$jsonExt["cnt5"] = ((array_key_exists('cnt5', $json)) ? ($json["cnt5"][0]) : ( -1));
		$jsonExt["cnt5_e"] = ((array_key_exists('cnt5', $json)) ? ($json["cnt5"][1]) : ( -1));
		$jsonExt["cnt10"] = ((array_key_exists('cnt10', $json)) ? ($json["cnt10"][0]) : ( -1));
		$jsonExt["cnt10_e"] = ((array_key_exists('cnt10', $json)) ? ($json["cnt10"][1]) : ( -1));
		$jsonExt["TypPS"] = ((array_key_exists('TypPS', $json)) ? ($json["TypPS"]) : ( -1));
		$jsonExt["sound"] = ((array_key_exists('sound', $json)) ? ($json["sound"][0]) : ( -1));
		$jsonExt["sound_e"] = ((array_key_exists('sound', $json)) ? ($json["sound"][1]) : ( -1));

		// V 1.78 
		//$jsonExt["sound_max"] = ((array_key_exists('sound_max', $json)) ? ($json["sound_max"]) : ( -1));
		
		// V1.79  
		$jsonExt["sound_max"] = ((array_key_exists('sound_max', $json)) ? ($json["sound_max"][0]) : ( -1));
		$jsonExt["sound_max_e"] = ((array_key_exists('sound_max', $json)) ? ($json["sound_max"][1]) : ( -1));

		$jsonExt["pressure"] = ((array_key_exists('pressure', $json)) ? ($json["pressure"][0]) : ( -1));
		$jsonExt["pressure_e"] = ((array_key_exists('pressure', $json)) ? ($json["pressure"][1]) : ( -1));
		$jsonExt["Status"] = $status;
		
		return  json_encode($jsonExt);
	}

?>